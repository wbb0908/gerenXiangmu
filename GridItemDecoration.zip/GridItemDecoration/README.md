# GridItemDecoration
#### 为 GridLayout 的 RecyclerView 设置 item 间距，实现所有 Item 靠边对齐，中间留白的效果

![效果图](http://img.blog.csdn.net/20170511100508040?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvemdoMDcxMQ==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)


具体内容见 [我的博客](http://blog.csdn.net/zgh0711/article/details/71422516)